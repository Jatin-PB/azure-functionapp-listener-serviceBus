﻿using Azure.Messaging.ServiceBus;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace KCW1Publisher.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PublishController : ControllerBase
    {
        private readonly string connectionString = "Endpoint=sb://kcwservice.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=ejLNfQ9aDv7vHi9kkhCY5iLL0ql0Wr9g6+ASbCTI2SE=";
        private readonly string topicName = "poc-messages";

        [HttpPost]
        public async Task<IActionResult> SendMessage()
        {
            string senderId = "Publisher1"; // Change this for each project

            await using var client = new ServiceBusClient(connectionString);
            ServiceBusSender sender = client.CreateSender(topicName);


            var messagePayload = new
            {
                messageEnvelope = new
                {
                    messageId = "8390684a-0ff9-48f9-8a21-c416d63e1efe",
                    timestamp = "2025-09-16T19:45:00Z",
                    sender = new
                    {
                        role = "GroupAuditor",
                        userId = "tomhanks@kpmg.com",
                        name = "Tom Hanks"
                    },
                    receiver = new
                    {
                        role = "ComponentAuditor",
                        userId = "mathrew@kpmg.com",
                        name = "Mathew Smith"
                    },
                    engagement = new
                    {
                        groupEngagementId = "b0fd6f9e-18b7-4e4c-b361-46034e686512",
                        componentEngagementId = "d4a6f216-f725-480f-b178-a3a65cc72bdc",
                        sourceEngagementHostName = "kcw.stg.amr.kpmg.com",
                        targetEngagementHostName = "kcw4.stg.amr.kpmg.com"
                    },
                    workflow = new
                    {
                        type = "AuditProcedureExchange",
                        version = "v1.1"
                    },
                    eventType = "ProcedureStatusUpdate"
                },
                procedure = new
                {
                    procedureId = "PROC-0001",
                    title = "Review Revenue Recognition",
                    description = "Audit procedure for revenue recognition under KCW engagement.",
                    status = new
                    {
                        currentStatus = "Allocated",
                        lastUpdated = "2025-09-17T10:30:00Z"
                    },
                    dueDate = "2025-09-20",
                    workspace = "KCW-Audit-Workspace",
                    documentCount = 1,
                    documentNames = "Revenue_Procedure_Template.docx",
                    documents = new[] {
            new {
                fileName = "Revenue_Procedure_Template.docx",
                fileUrl = "https://storage.company.com/auditdocs/Revenue_Procedure_Template.docx"
            }
        },
                    action = new
                    {
                        requested = "Execute",
                        response = new
                        {
                            status = "Approved",
                            comments = "Procedure reviewed and approved. No issues found.",
                            timestamp = "2025-09-17T10:30:00Z"
                        }
                    }
                }
            ,claraInstantID = senderId
            };

            string jsonMessage = JsonSerializer.Serialize(messagePayload);


            var message = new ServiceBusMessage(jsonMessage);
            await sender.SendMessageAsync(message);

            return Ok(new { Status = "Message Sent", Sender = senderId });
        }
    }

}
